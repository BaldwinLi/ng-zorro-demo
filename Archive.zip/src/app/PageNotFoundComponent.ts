import { Component } from '@angular/core';

@Component({
  selector: 'app-page-notfound',
  template: '<img src="./assets/img/404.jpg" class="platform-screen">',
  styleUrls: ['../assets/css/custom.css']
})
export class PageNotFoundComponent {
}
