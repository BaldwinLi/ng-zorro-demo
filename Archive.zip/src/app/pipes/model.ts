import { Injectable } from '@angular/core';

@Injectable()
export class DataModelService {
    constructor() {

    }


    init(): any {
    }

    private buildDataModel(data): void {
    }

}
